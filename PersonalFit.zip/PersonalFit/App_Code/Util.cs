﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Util
/// </summary>
public abstract class Util
{
    public const String defaultEmail = "buzz.lightyear8000@gmail.com";
    public const String password = "Xn140839";

}